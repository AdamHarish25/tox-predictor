# Install required dependencies if not already installed
npm install clsx tailwind-merge class-variance-authority
