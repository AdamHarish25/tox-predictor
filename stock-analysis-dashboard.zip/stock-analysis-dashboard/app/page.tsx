import MLDashboard from "@/components/ml-dashboard"

export default function Home() {
  return <MLDashboard />
}
