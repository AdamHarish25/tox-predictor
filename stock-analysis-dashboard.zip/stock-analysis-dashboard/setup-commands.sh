# Install required dependencies
npm install clsx tailwind-merge class-variance-authority
npm install @radix-ui/react-slot @radix-ui/react-tabs
npm install lucide-react recharts next-themes
npm install tailwindcss-animate autoprefixer postcss

# Install development dependencies
npm install -D tailwindcss
