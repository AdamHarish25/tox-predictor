# Install required packages
npm install next-themes
npm install lucide-react
npm install recharts

# Install shadcn/ui components
npx shadcn@latest add card
npx shadcn@latest add tabs
npx shadcn@latest add button
